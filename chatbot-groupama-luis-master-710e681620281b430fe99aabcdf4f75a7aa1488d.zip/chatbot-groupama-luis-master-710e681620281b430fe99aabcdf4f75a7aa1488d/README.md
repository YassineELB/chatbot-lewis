# INFO

- Use Paul-Emile DUGNAT's profile for dev

# TODO & PROBLEMS

- Move the logic away from React components!
- Utterance review currently only works with intents, not entities (not implemented)
- You might encounter HTTP Error 429 (Too Many Requests) sometimes (I even had the problem with only two or three calls per refresh)
- Bind app keys to environment variables for security
